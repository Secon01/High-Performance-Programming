float fun1(float* p, int k);
float fun2(float* p, int k);
