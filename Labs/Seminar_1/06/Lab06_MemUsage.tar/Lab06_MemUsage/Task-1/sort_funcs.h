void bubble_sort(int* list, int N);
void merge_sort (int* list, int N);
