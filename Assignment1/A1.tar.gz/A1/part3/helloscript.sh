echo Hej hej
echo Mjolk och kaffe
echo Kaffe eller te?
echo Brod och kaffe, tack!
